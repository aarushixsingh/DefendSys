
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Settings, Shield, Clock, Bell, Lock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';

const SettingsPage: React.FC = () => {
  // Protection settings
  const [realtimeProtection, setRealtimeProtection] = useState(true);
  const [downloadProtection, setDownloadProtection] = useState(true);
  const [emailProtection, setEmailProtection] = useState(false);
  const [webProtection, setWebProtection] = useState(true);
  const [ransomwareProtection, setRansomwareProtection] = useState(true);
  
  // Scan settings
  const [scheduledScans, setScheduledScans] = useState(true);
  const [scanFrequency, setScanFrequency] = useState('daily');
  const [scanTime, setScanTime] = useState('00:00');
  
  // Notification settings
  const [threatNotifications, setThreatNotifications] = useState(true);
  const [scanCompletionNotifications, setScanCompletionNotifications] = useState(true);
  const [updateNotifications, setUpdateNotifications] = useState(true);
  
  const handleSaveSettings = () => {
    toast.success("Settings saved successfully", {
      description: "Your security preferences have been updated.",
    });
  };
  
  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Settings</h1>
        <Button 
          className="bg-defendsys-blue hover:bg-defendsys-dark-blue"
          onClick={handleSaveSettings}
        >
          Save Settings
        </Button>
      </div>
      
      <div className="space-y-6">
        {/* Protection Settings */}
        <Card>
          <CardHeader className="bg-defendsys-blue text-white p-4">
            <CardTitle className="flex items-center gap-2 text-lg">
              <Shield size={20} />
              Protection Settings
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">Real-time System Protection</h3>
                  <p className="text-sm text-gray-500">Continuously monitor and scan files as they're accessed</p>
                </div>
                <Switch
                  checked={realtimeProtection}
                  onCheckedChange={setRealtimeProtection}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">Download Protection</h3>
                  <p className="text-sm text-gray-500">Scan files as they're downloaded from the internet</p>
                </div>
                <Switch
                  checked={downloadProtection}
                  onCheckedChange={setDownloadProtection}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">Email Protection</h3>
                  <p className="text-sm text-gray-500">Scan email attachments for malware</p>
                </div>
                <Switch
                  checked={emailProtection}
                  onCheckedChange={setEmailProtection}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">Web Protection</h3>
                  <p className="text-sm text-gray-500">Block access to malicious websites</p>
                </div>
                <Switch
                  checked={webProtection}
                  onCheckedChange={setWebProtection}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">Ransomware Protection</h3>
                  <p className="text-sm text-gray-500">Prevent unauthorized encryption of your files</p>
                </div>
                <Switch
                  checked={ransomwareProtection}
                  onCheckedChange={setRansomwareProtection}
                />
              </div>
            </div>
          </CardContent>
        </Card>
        
        {/* Scan Settings */}
        <Card>
          <CardHeader className="bg-defendsys-blue text-white p-4">
            <CardTitle className="flex items-center gap-2 text-lg">
              <Clock size={20} />
              Scan Settings
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">Scheduled Scans</h3>
                  <p className="text-sm text-gray-500">Automatically scan your system on a schedule</p>
                </div>
                <Switch
                  checked={scheduledScans}
                  onCheckedChange={setScheduledScans}
                />
              </div>
              
              {scheduledScans && (
                <>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium block mb-2">Scan Frequency</label>
                      <Select value={scanFrequency} onValueChange={setScanFrequency}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select frequency" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="daily">Daily</SelectItem>
                          <SelectItem value="weekly">Weekly</SelectItem>
                          <SelectItem value="monthly">Monthly</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div>
                      <label className="text-sm font-medium block mb-2">Scan Time</label>
                      <input
                        type="time"
                        value={scanTime}
                        onChange={(e) => setScanTime(e.target.value)}
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                      />
                    </div>
                  </div>
                </>
              )}
            </div>
          </CardContent>
        </Card>
        
        {/* Notification Settings */}
        <Card>
          <CardHeader className="bg-defendsys-blue text-white p-4">
            <CardTitle className="flex items-center gap-2 text-lg">
              <Bell size={20} />
              Notification Settings
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">Threat Alerts</h3>
                  <p className="text-sm text-gray-500">Get notified when threats are detected</p>
                </div>
                <Switch
                  checked={threatNotifications}
                  onCheckedChange={setThreatNotifications}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">Scan Completion</h3>
                  <p className="text-sm text-gray-500">Get notified when scans complete</p>
                </div>
                <Switch
                  checked={scanCompletionNotifications}
                  onCheckedChange={setScanCompletionNotifications}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">Updates</h3>
                  <p className="text-sm text-gray-500">Get notified about software updates</p>
                </div>
                <Switch
                  checked={updateNotifications}
                  onCheckedChange={setUpdateNotifications}
                />
              </div>
            </div>
          </CardContent>
        </Card>
        
        {/* About */}
        <Card>
          <CardHeader className="bg-defendsys-blue text-white p-4">
            <CardTitle className="flex items-center gap-2 text-lg">
              <Lock size={20} />
              About DefendSys
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <div className="space-y-4">
              <div>
                <h3 className="font-medium">DefendSys Antivirus</h3>
                <p className="text-sm text-gray-500">Version 1.0.0</p>
              </div>
              
              <div>
                <h3 className="font-medium">Virus Definition</h3>
                <p className="text-sm text-gray-500">Last updated: {new Date().toLocaleDateString()}</p>
              </div>
              
              <div>
                <h3 className="font-medium">License</h3>
                <p className="text-sm text-gray-500">Premium (Active)</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default SettingsPage;
