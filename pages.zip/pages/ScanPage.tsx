
import React, { useState, useEffect } from 'react';
import ScanOption from '@/components/scan/ScanOption';
import ScanProgress from '@/components/scan/ScanProgress';
import FileUploadScan from '@/components/scan/FileUploadScan';
import { Zap, Search, FileSearch } from 'lucide-react';
import { toast } from 'sonner';

type ScanType = 'quick' | 'deep' | 'file' | null;

const ScanPage: React.FC = () => {
  const [activeScan, setActiveScan] = useState<ScanType>(null);
  const [progress, setProgress] = useState(0);
  const [filesScanned, setFilesScanned] = useState(0);
  const [threatsFound, setThreatsFound] = useState(0);
  const [currentFile, setCurrentFile] = useState('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  
  // Mock file paths for scanning animation
  const mockFilePaths = [
    'C:/Windows/System32/drivers/etc/hosts',
    'C:/Program Files/Common Files/System/ado/msado15.dll',
    'C:/Users/Admin/Downloads/installer.exe',
    'C:/Users/Admin/Documents/important.pdf',
    'C:/Program Files/Internet Explorer/iexplore.exe',
    'C:/Windows/System32/calc.exe',
    'C:/Users/Admin/Pictures/vacation.jpg',
    'C:/Users/Admin/Desktop/work.docx',
  ];
  
  useEffect(() => {
    if (!activeScan) return;
    
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          return 100;
        }
        return prev + 1;
      });
      
      setFilesScanned((prev) => prev + Math.floor(Math.random() * 5) + 1);
      
      if (Math.random() < 0.05) {
        setThreatsFound((prev) => prev + 1);
        toast.warning("Potential threat detected", {
          description: "Suspicious file identified during scan.",
        });
      }
      
      setCurrentFile(mockFilePaths[Math.floor(Math.random() * mockFilePaths.length)]);
    }, activeScan === 'quick' ? 100 : activeScan === 'deep' ? 200 : 150);
    
    return () => clearInterval(interval);
  }, [activeScan]);
  
  const handleCancelScan = () => {
    setActiveScan(null);
    setProgress(0);
    setFilesScanned(0);
    setThreatsFound(0);
    setCurrentFile('');
    setSelectedFile(null);
    toast.info("Scan canceled");
  };
  
  const handleStartQuickScan = () => {
    setActiveScan('quick');
    setProgress(0);
    setFilesScanned(0);
    setThreatsFound(0);
    toast.info("Quick scan started");
  };
  
  const handleStartDeepScan = () => {
    setActiveScan('deep');
    setProgress(0);
    setFilesScanned(0);
    setThreatsFound(0);
    toast.info("Deep scan started");
  };
  
  const handleFileScan = (file: File) => {
    setSelectedFile(file);
    setActiveScan('file');
    setProgress(0);
    setFilesScanned(0);
    setThreatsFound(0);
    setCurrentFile(file.name);
    toast.info(`Scanning file: ${file.name}`);
  };
  
  // When scan reaches 100%
  useEffect(() => {
    if (progress === 100 && activeScan) {
      if (threatsFound > 0) {
        toast.error(`Scan complete. ${threatsFound} threats found!`, {
          description: "Check the Threats page for details.",
        });
      } else {
        toast.success("Scan complete. No threats found!", {
          description: "Your system is clean.",
        });
      }
    }
  }, [progress, activeScan, threatsFound]);
  
  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Scan Center</h1>
      </div>
      
      {activeScan ? (
        <ScanProgress
          scanType={activeScan}
          progress={progress}
          filesScanned={filesScanned}
          threatsFound={threatsFound}
          currentFile={currentFile}
          onCancel={handleCancelScan}
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-6">
            <ScanOption
              title="Quick Scan"
              description="Rapidly scan critical system files and active processes for immediate threats."
              icon={<Zap size={24} />}
              duration="2-5 minutes"
              onClick={handleStartQuickScan}
            />
            
            <ScanOption
              title="Deep Scan"
              description="Thoroughly examine all files, folders, and system areas for hidden malware."
              icon={<Search size={24} />}
              duration="30-60 minutes"
              onClick={handleStartDeepScan}
            />
          </div>
          
          <div>
            <FileUploadScan onScanFile={handleFileScan} />
          </div>
        </div>
      )}
    </div>
  );
};

export default ScanPage;
