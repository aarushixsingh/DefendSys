
import React from 'react';
import ProtectionStatus from '@/components/dashboard/ProtectionStatus';
import SystemSummary from '@/components/dashboard/SystemSummary';
import RealtimeProtection from '@/components/dashboard/RealtimeProtection';

const Dashboard: React.FC = () => {
  // Mock data
  const protectionFeatures = [
    { name: 'Real-time System Scanning', isActive: true },
    { name: 'File Download Protection', isActive: true },
    { name: 'Email Scanning', isActive: false },
    { name: 'Web Protection', isActive: true },
    { name: 'Ransomware Protection', isActive: true },
  ];

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-gray-900">DefendSys Dashboard</h1>
        <div className="text-sm text-gray-500">Last update: {new Date().toLocaleString()}</div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <ProtectionStatus status="protected" score={92} />
        
        <div className="md:col-span-2">
          <SystemSummary
            totalScans={47}
            lastScanDate="Today, 9:30 AM"
            threatsDetected={3}
            systemUptime="5 days, 7 hours"
          />
        </div>
      </div>

      <div className="mt-6">
        <RealtimeProtection features={protectionFeatures} />
      </div>

      <div className="mt-6 bg-white p-6 rounded-lg border border-gray-200">
        <h2 className="text-lg font-medium text-gray-900 mb-4">Welcome to DefendSys</h2>
        <p className="text-gray-600">
          DefendSys is your comprehensive antivirus solution, providing real-time protection against all types of malware, 
          viruses, and cyber threats. With features like system scanning, threat detection, and file analysis, 
          your device stays secure against emerging threats.
        </p>
        <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-gray-50 p-4 rounded-lg">
            <h3 className="font-medium text-gray-900">Real-time Scanning</h3>
            <p className="text-sm text-gray-600 mt-1">
              Continuous monitoring of your system to detect and block threats in real-time.
            </p>
          </div>
          <div className="bg-gray-50 p-4 rounded-lg">
            <h3 className="font-medium text-gray-900">Threat Detection</h3>
            <p className="text-sm text-gray-600 mt-1">
              Advanced algorithms to identify known and unknown threats with high accuracy.
            </p>
          </div>
          <div className="bg-gray-50 p-4 rounded-lg">
            <h3 className="font-medium text-gray-900">Protection Score</h3>
            <p className="text-sm text-gray-600 mt-1">
              An overall assessment of your system's security status and recommendations.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
