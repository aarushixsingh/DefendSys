
import React, { useState } from 'react';
import ThreatList, { Threat } from '@/components/threats/ThreatList';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Shield, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

const ThreatsPage: React.FC = () => {
  // Mock initial threats data
  const initialThreats: Threat[] = [
    {
      id: '1',
      name: 'Trojan.Win32.Agent',
      path: 'C:/Users/Admin/Downloads/setup_installer.exe',
      type: 'Trojan',
      severity: 'high',
      status: 'detected',
      detectedAt: '2023-04-03 10:15 AM',
    },
    {
      id: '2',
      name: 'Adware.Win32.Amonetize',
      path: 'C:/Program Files/BrowserAssistant/helper.dll',
      type: 'Adware',
      severity: 'medium',
      status: 'quarantined',
      detectedAt: '2023-04-02 03:22 PM',
    },
    {
      id: '3',
      name: 'Worm.Win32.Autorun',
      path: 'C:/Windows/System32/drivers/etc/suspicious.dll',
      type: 'Worm',
      severity: 'critical',
      status: 'detected',
      detectedAt: '2023-04-03 09:45 AM',
    },
  ];

  const [threats, setThreats] = useState<Threat[]>(initialThreats);
  
  const handleQuarantine = (id: string) => {
    setThreats(prevThreats =>
      prevThreats.map(threat =>
        threat.id === id ? { ...threat, status: 'quarantined' } : threat
      )
    );
    toast.success("Threat quarantined", {
      description: "The file has been isolated from your system.",
    });
  };
  
  const handleDelete = (id: string) => {
    setThreats(prevThreats =>
      prevThreats.map(threat =>
        threat.id === id ? { ...threat, status: 'removed' } : threat
      )
    );
    toast.success("Threat removed", {
      description: "The file has been permanently deleted from your system.",
    });
  };
  
  const handleRestore = (id: string) => {
    setThreats(prevThreats =>
      prevThreats.map(threat =>
        threat.id === id ? { ...threat, status: 'detected' } : threat
      )
    );
    toast.warning("File restored", {
      description: "The file has been restored to its original location.",
    });
  };
  
  const handleRemoveAll = () => {
    setThreats(prevThreats =>
      prevThreats.map(threat => ({ ...threat, status: 'removed' }))
    );
    toast.success("All threats removed", {
      description: "All detected threats have been permanently removed from your system.",
    });
  };
  
  const handleQuarantineAll = () => {
    setThreats(prevThreats =>
      prevThreats.map(threat =>
        threat.status === 'detected' ? { ...threat, status: 'quarantined' } : threat
      )
    );
    toast.success("All threats quarantined", {
      description: "All detected threats have been isolated from your system.",
    });
  };
  
  const detectionsCount = threats.filter(t => t.status === 'detected').length;
  const quarantinedCount = threats.filter(t => t.status === 'quarantined').length;
  const removedCount = threats.filter(t => t.status === 'removed').length;
  
  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Threat Detection</h1>
        <div className="flex gap-3">
          {detectionsCount > 0 && (
            <>
              <Button
                variant="outline"
                className="border-yellow-500 text-yellow-600 hover:bg-yellow-50"
                onClick={handleQuarantineAll}
              >
                Quarantine All
              </Button>
              <Button
                variant="outline"
                className="border-red-500 text-red-600 hover:bg-red-50"
                onClick={handleRemoveAll}
              >
                Remove All
              </Button>
            </>
          )}
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="bg-red-100 p-3 rounded-full">
                <AlertTriangle className="h-6 w-6 text-red-600" />
              </div>
              <div>
                <div className="text-sm text-gray-500">Detected</div>
                <div className="text-2xl font-bold text-gray-900">{detectionsCount}</div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="bg-yellow-100 p-3 rounded-full">
                <Shield className="h-6 w-6 text-yellow-600" />
              </div>
              <div>
                <div className="text-sm text-gray-500">Quarantined</div>
                <div className="text-2xl font-bold text-gray-900">{quarantinedCount}</div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="bg-green-100 p-3 rounded-full">
                <Shield className="h-6 w-6 text-green-600" />
              </div>
              <div>
                <div className="text-sm text-gray-500">Removed</div>
                <div className="text-2xl font-bold text-gray-900">{removedCount}</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <ThreatList
        threats={threats}
        onQuarantine={handleQuarantine}
        onDelete={handleDelete}
        onRestore={handleRestore}
      />
    </div>
  );
};

export default ThreatsPage;
