
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { FileUp, AlertTriangle, FileCheck } from 'lucide-react';

type FileUploadScanProps = {
  onScanFile: (file: File) => void;
};

const FileUploadScan: React.FC<FileUploadScanProps> = ({ onScanFile }) => {
  const [file, setFile] = useState<File | null>(null);
  const [isDragOver, setIsDragOver] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = () => {
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragOver(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      setFile(e.dataTransfer.files[0]);
    }
  };

  const handleScanClick = () => {
    if (file) {
      onScanFile(file);
    }
  };

  return (
    <Card>
      <CardHeader className="bg-defendsys-blue text-white p-4">
        <CardTitle className="flex items-center gap-2 text-lg">
          <FileUp size={20} />
          Custom File Scan
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-6 pb-4">
        <div
          className={`border-2 border-dashed rounded-lg p-6 text-center ${
            isDragOver ? 'border-defendsys-blue bg-blue-50' : 'border-gray-300'
          }`}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
        >
          <FileUp className="mx-auto h-12 w-12 text-gray-400" />
          <p className="mt-2 text-sm text-gray-600">
            Drag and drop a file here, or{' '}
            <label className="text-defendsys-blue cursor-pointer hover:underline">
              browse
              <input
                type="file"
                className="hidden"
                onChange={handleFileChange}
              />
            </label>
          </p>
          <p className="mt-1 text-xs text-gray-500">
            Upload a file you want to scan for threats
          </p>
        </div>

        {file && (
          <div className="mt-4 p-3 bg-gray-50 rounded-lg">
            <div className="flex items-start gap-3">
              <FileCheck className="h-5 w-5 text-gray-400 mt-1" />
              <div className="flex-1 overflow-hidden">
                <p className="font-medium text-sm truncate">{file.name}</p>
                <p className="text-xs text-gray-500">
                  {(file.size / 1024 / 1024).toFixed(2)} MB
                </p>
              </div>
            </div>
          </div>
        )}

        <Button
          className="w-full mt-4 bg-defendsys-blue hover:bg-defendsys-dark-blue"
          disabled={!file}
          onClick={handleScanClick}
        >
          <AlertTriangle className="mr-2 h-4 w-4" />
          Scan File
        </Button>
      </CardContent>
    </Card>
  );
};

export default FileUploadScan;
