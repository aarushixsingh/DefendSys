
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

type ScanOptionProps = {
  title: string;
  description: string;
  icon: React.ReactNode;
  duration: string;
  onClick: () => void;
  isActive?: boolean;
};

const ScanOption: React.FC<ScanOptionProps> = ({
  title,
  description,
  icon,
  duration,
  onClick,
  isActive = false,
}) => {
  return (
    <Card 
      className={cn(
        "transition-all cursor-pointer hover:shadow-md",
        isActive && "border-defendsys-blue border-2"
      )}
      onClick={onClick}
    >
      <CardContent className="p-6">
        <div className="flex items-start gap-4">
          <div className="bg-defendsys-blue bg-opacity-10 p-3 rounded-lg text-defendsys-blue">
            {icon}
          </div>
          
          <div className="flex-1">
            <h3 className="text-lg font-semibold text-gray-900">{title}</h3>
            <p className="text-sm text-gray-500 mt-1">{description}</p>
            <div className="mt-4 flex items-center justify-between">
              <span className="text-xs text-gray-500">Duration: {duration}</span>
              <Button 
                size="sm" 
                className="bg-defendsys-blue hover:bg-defendsys-dark-blue"
                onClick={(e) => {
                  e.stopPropagation();
                  onClick();
                }}
              >
                Start
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default ScanOption;
