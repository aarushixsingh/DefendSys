
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Search, AlertTriangle, X } from 'lucide-react';
import { Button } from '@/components/ui/button';

type ScanProgressProps = {
  scanType: 'quick' | 'deep' | 'file';
  progress: number;
  filesScanned: number;
  threatsFound: number;
  currentFile: string;
  onCancel: () => void;
};

const ScanProgress: React.FC<ScanProgressProps> = ({
  scanType,
  progress,
  filesScanned,
  threatsFound,
  currentFile,
  onCancel,
}) => {
  const getScanTypeText = () => {
    switch (scanType) {
      case 'quick':
        return 'Quick Scan';
      case 'deep':
        return 'Deep Scan';
      case 'file':
        return 'Custom File Scan';
      default:
        return 'Scan';
    }
  };

  return (
    <Card>
      <CardHeader className="bg-defendsys-blue text-white p-4">
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-lg">
            <Search size={20} />
            {getScanTypeText()} In Progress
          </div>
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={onCancel}
            className="text-white hover:bg-white hover:bg-opacity-20"
          >
            <X size={18} />
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-6 pb-4">
        <div className="space-y-4">
          <div>
            <div className="flex justify-between mb-2">
              <span className="text-sm font-medium">
                {progress < 100 ? 'Scanning...' : 'Scan Complete'}
              </span>
              <span className="text-sm font-medium">{progress}%</span>
            </div>
            <Progress value={progress} className="h-2" />
          </div>
          
          <div className="grid grid-cols-2 gap-4 mt-4">
            <div className="bg-gray-50 p-3 rounded-lg">
              <div className="text-sm text-gray-500">Files Scanned</div>
              <div className="font-semibold">{filesScanned}</div>
            </div>
            
            <div className="bg-gray-50 p-3 rounded-lg">
              <div className="text-sm text-gray-500">Threats Found</div>
              <div className="font-semibold text-defendsys-red flex items-center gap-1">
                {threatsFound}
                {threatsFound > 0 && <AlertTriangle size={14} />}
              </div>
            </div>
          </div>
          
          <div className="bg-gray-50 p-3 rounded-lg">
            <div className="text-sm text-gray-500">Currently Scanning</div>
            <div className="text-xs text-gray-700 truncate mt-1 font-mono">
              {currentFile}
            </div>
          </div>
          
          {progress < 100 && (
            <Button
              variant="outline"
              className="w-full border-defendsys-red text-defendsys-red hover:bg-red-50"
              onClick={onCancel}
            >
              <X size={16} className="mr-2" />
              Cancel Scan
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default ScanProgress;
