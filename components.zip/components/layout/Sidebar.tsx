
import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Shield, Search, AlertTriangle, Settings, Home } from 'lucide-react';
import { cn } from '@/lib/utils';

type NavItemProps = {
  to: string;
  icon: React.ReactNode;
  label: string;
  isActive: boolean;
};

const NavItem: React.FC<NavItemProps> = ({ to, icon, label, isActive }) => {
  return (
    <Link
      to={to}
      className={cn(
        "flex items-center gap-3 px-4 py-3 rounded-lg transition-all",
        isActive 
          ? "bg-defendsys-blue text-white" 
          : "hover:bg-gray-100 text-gray-700 hover:text-defendsys-blue"
      )}
    >
      <div className="w-5 h-5">{icon}</div>
      <span className="font-medium">{label}</span>
    </Link>
  );
};

const Sidebar: React.FC = () => {
  const location = useLocation();
  const currentPath = location.pathname;

  const navItems = [
    { to: '/', icon: <Home size={20} />, label: 'Dashboard' },
    { to: '/scan', icon: <Search size={20} />, label: 'Scan' },
    { to: '/threats', icon: <AlertTriangle size={20} />, label: 'Threats' },
    { to: '/settings', icon: <Settings size={20} />, label: 'Settings' },
  ];

  return (
    <div className="w-64 h-screen bg-white border-r border-gray-200 p-4 flex flex-col">
      <div className="flex items-center gap-2 px-4 py-6">
        <Shield className="h-8 w-8 text-defendsys-blue" />
        <h1 className="text-xl font-bold text-defendsys-blue">DefendSys</h1>
      </div>
      
      <div className="mt-6 space-y-2">
        {navItems.map((item) => (
          <NavItem
            key={item.to}
            to={item.to}
            icon={item.icon}
            label={item.label}
            isActive={
              currentPath === item.to || 
              (item.to !== '/' && currentPath.startsWith(item.to))
            }
          />
        ))}
      </div>
      
      <div className="mt-auto p-4 bg-defendsys-gray rounded-lg">
        <div className="text-sm font-medium text-gray-800">DefendSys</div>
        <div className="text-xs text-gray-500">Version 1.0.0</div>
      </div>
    </div>
  );
};

export default Sidebar;
