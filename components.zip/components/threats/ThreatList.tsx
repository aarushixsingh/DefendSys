
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { AlertTriangle, Shield, Trash2, Archive } from 'lucide-react';
import { cn } from '@/lib/utils';

export type Threat = {
  id: string;
  name: string;
  path: string;
  type: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  status: 'quarantined' | 'removed' | 'detected';
  detectedAt: string;
};

type ThreatListProps = {
  threats: Threat[];
  onQuarantine: (id: string) => void;
  onDelete: (id: string) => void;
  onRestore: (id: string) => void;
};

const ThreatList: React.FC<ThreatListProps> = ({
  threats,
  onQuarantine,
  onDelete,
  onRestore,
}) => {
  const getSeverityColor = (severity: Threat['severity']) => {
    switch (severity) {
      case 'low':
        return 'bg-blue-100 text-blue-800';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800';
      case 'high':
        return 'bg-orange-100 text-orange-800';
      case 'critical':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: Threat['status']) => {
    switch (status) {
      case 'quarantined':
        return <Archive size={16} className="text-yellow-600" />;
      case 'removed':
        return <Trash2 size={16} className="text-green-600" />;
      case 'detected':
        return <AlertTriangle size={16} className="text-red-600" />;
      default:
        return null;
    }
  };

  const getStatusText = (status: Threat['status']) => {
    switch (status) {
      case 'quarantined':
        return 'Quarantined';
      case 'removed':
        return 'Removed';
      case 'detected':
        return 'Detected';
      default:
        return status;
    }
  };

  return (
    <Card>
      <CardHeader className="bg-defendsys-blue text-white p-4">
        <CardTitle className="flex items-center gap-2 text-lg">
          <Shield size={20} />
          Detected Threats
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        {threats.length === 0 ? (
          <div className="py-12 text-center">
            <Shield className="h-12 w-12 mx-auto text-gray-400" />
            <p className="mt-2 text-gray-500">No threats detected</p>
            <p className="text-sm text-gray-400">
              Your system is clean and secure
            </p>
          </div>
        ) : (
          <div className="divide-y divide-gray-100">
            {threats.map((threat) => (
              <div key={threat.id} className="p-4">
                <div className="flex justify-between items-start">
                  <div>
                    <div className="flex items-center gap-2">
                      <AlertTriangle
                        size={18}
                        className="text-defendsys-red"
                      />
                      <h3 className="font-medium">{threat.name}</h3>
                      <span
                        className={cn(
                          'px-2 py-1 rounded-full text-xs font-medium',
                          getSeverityColor(threat.severity)
                        )}
                      >
                        {threat.severity}
                      </span>
                    </div>
                    <p className="text-xs text-gray-500 mt-1 font-mono">
                      {threat.path}
                    </p>
                    <div className="mt-2 flex items-center gap-2">
                      <span className="text-xs text-gray-500">
                        Type: {threat.type}
                      </span>
                      <span className="text-xs flex items-center gap-1">
                        {getStatusIcon(threat.status)}
                        {getStatusText(threat.status)}
                      </span>
                      <span className="text-xs text-gray-500">
                        Detected: {threat.detectedAt}
                      </span>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    {threat.status === 'detected' && (
                      <Button
                        size="sm"
                        variant="outline"
                        className="border-yellow-500 text-yellow-600 hover:bg-yellow-50"
                        onClick={() => onQuarantine(threat.id)}
                      >
                        <Archive size={14} className="mr-1" />
                        Quarantine
                      </Button>
                    )}
                    {threat.status !== 'removed' && (
                      <Button
                        size="sm"
                        variant="outline"
                        className="border-red-500 text-red-600 hover:bg-red-50"
                        onClick={() => onDelete(threat.id)}
                      >
                        <Trash2 size={14} className="mr-1" />
                        Remove
                      </Button>
                    )}
                    {threat.status === 'quarantined' && (
                      <Button
                        size="sm"
                        variant="outline"
                        className="border-gray-300 text-gray-600 hover:bg-gray-50"
                        onClick={() => onRestore(threat.id)}
                      >
                        Restore
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default ThreatList;
