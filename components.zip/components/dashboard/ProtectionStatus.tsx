
import React from 'react';
import { Shield, CheckCircle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

type ProtectionStatusProps = {
  status: 'protected' | 'at-risk' | 'vulnerable';
  score: number;
};

const ProtectionStatus: React.FC<ProtectionStatusProps> = ({ status, score }) => {
  const getStatusColor = () => {
    switch (status) {
      case 'protected':
        return 'text-defendsys-green';
      case 'at-risk':
        return 'text-defendsys-yellow';
      case 'vulnerable':
        return 'text-defendsys-red';
      default:
        return 'text-defendsys-green';
    }
  };

  const getStatusText = () => {
    switch (status) {
      case 'protected':
        return 'Protected';
      case 'at-risk':
        return 'At Risk';
      case 'vulnerable':
        return 'Vulnerable';
      default:
        return 'Protected';
    }
  };

  return (
    <Card className="overflow-hidden">
      <CardHeader className="bg-defendsys-blue text-white p-4">
        <CardTitle className="flex items-center gap-2 text-lg">
          <Shield size={20} />
          Protection Status
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-6 pb-4">
        <div className="flex flex-col items-center justify-center">
          <div className="relative w-32 h-32 mb-4">
            <div className="absolute inset-0 rounded-full border-4 border-gray-100 flex items-center justify-center">
              <div className="text-3xl font-bold">{score}%</div>
            </div>
            <svg className="absolute inset-0 transform -rotate-90" width="100%" height="100%" viewBox="0 0 100 100">
              <circle 
                cx="50" 
                cy="50" 
                r="45" 
                fill="none" 
                stroke="#E5E7EB" 
                strokeWidth="8" 
              />
              <circle 
                cx="50" 
                cy="50" 
                r="45" 
                fill="none" 
                stroke={
                  status === 'protected' 
                    ? '#16A34A' 
                    : status === 'at-risk' 
                    ? '#EAB308' 
                    : '#DC2626'
                } 
                strokeWidth="8" 
                strokeDasharray={`${score * 2.83} 283`}
                strokeLinecap="round" 
              />
            </svg>
          </div>
          <div className="flex items-center gap-2">
            <CheckCircle className={`h-5 w-5 ${getStatusColor()}`} />
            <span className={`font-medium ${getStatusColor()}`}>
              {getStatusText()}
            </span>
          </div>
          <p className="text-sm text-gray-500 mt-2 text-center">
            Your system is {status === 'protected' ? 'fully protected' : 'not fully protected'}
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

export default ProtectionStatus;
