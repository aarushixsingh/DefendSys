
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Activity, Calendar, Clock, HardDrive } from 'lucide-react';

type SystemSummaryProps = {
  totalScans: number;
  lastScanDate: string;
  threatsDetected: number;
  systemUptime: string;
};

const SystemSummary: React.FC<SystemSummaryProps> = ({
  totalScans,
  lastScanDate,
  threatsDetected,
  systemUptime,
}) => {
  return (
    <Card>
      <CardHeader className="bg-defendsys-blue text-white p-4">
        <CardTitle className="flex items-center gap-2 text-lg">
          <Activity size={20} />
          System Summary
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-6 pb-4">
        <div className="grid grid-cols-2 gap-4">
          <div className="flex items-center gap-3">
            <div className="bg-blue-100 p-2 rounded-lg">
              <HardDrive className="h-5 w-5 text-defendsys-blue" />
            </div>
            <div>
              <div className="text-sm text-gray-500">Total Scans</div>
              <div className="font-semibold">{totalScans}</div>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <div className="bg-red-100 p-2 rounded-lg">
              <AlertTriangle className="h-5 w-5 text-defendsys-red" />
            </div>
            <div>
              <div className="text-sm text-gray-500">Threats Detected</div>
              <div className="font-semibold">{threatsDetected}</div>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <div className="bg-green-100 p-2 rounded-lg">
              <Calendar className="h-5 w-5 text-defendsys-green" />
            </div>
            <div>
              <div className="text-sm text-gray-500">Last Scan</div>
              <div className="font-semibold">{lastScanDate}</div>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <div className="bg-yellow-100 p-2 rounded-lg">
              <Clock className="h-5 w-5 text-defendsys-yellow" />
            </div>
            <div>
              <div className="text-sm text-gray-500">System Uptime</div>
              <div className="font-semibold">{systemUptime}</div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

import { AlertTriangle } from 'lucide-react';

export default SystemSummary;
