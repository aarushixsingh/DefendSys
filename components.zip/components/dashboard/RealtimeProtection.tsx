
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Shield, CheckCircle, XCircle } from 'lucide-react';

type ProtectionFeature = {
  name: string;
  isActive: boolean;
};

type RealtimeProtectionProps = {
  features: ProtectionFeature[];
};

const RealtimeProtection: React.FC<RealtimeProtectionProps> = ({ features }) => {
  return (
    <Card>
      <CardHeader className="bg-defendsys-blue text-white p-4">
        <CardTitle className="flex items-center gap-2 text-lg">
          <Shield size={20} />
          Realtime Protection
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-6 pb-4">
        <div className="space-y-4">
          {features.map((feature, index) => (
            <div 
              key={index} 
              className="flex items-center justify-between py-2 border-b border-gray-100 last:border-0"
            >
              <div className="font-medium text-gray-700">{feature.name}</div>
              <div>
                {feature.isActive ? (
                  <CheckCircle className="h-5 w-5 text-defendsys-green" />
                ) : (
                  <XCircle className="h-5 w-5 text-defendsys-red" />
                )}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default RealtimeProtection;
